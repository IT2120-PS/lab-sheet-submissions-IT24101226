getwd()
setwd("C:\\Users\\it24101226\\Desktop\\it24101226")

#Binomial  Distribution
dbinom(40,44,0.92)

pbinom(35,44,0.92,lower.tail=TRUE)

1- pbinom(37,44,0.92,lower.tail=TRUE)
pbinom(37,44,0.92,lower.tail = FALSE)

pbinom(42,44,0.92,lower.tail = TRUE)-pbinom(39,44,0.92,lower.tail=TRUE)


dpois(6,5)

ppois(6,5,lower.tail=FALSE)


# Question 1
# X = number of students who passed out of 50
# Distribution of X: Binomial(n = 50, p = 0.85)
#  Probability that at least 47 students passed
#     => P(X ≥ 47) = 1 - P(X ≤ 46)

# Use pbinom for cumulative binomial probability
prob_at_least_47 <- 1 - pbinom(46, 50, 0.85, lower.tail = TRUE)
prob_at_least_47

# Question 2 
# Random variable X = number of calls received in an hour
# Distribution of X: Poisson(λ = 12)
#  Probability that exactly 15 calls are received in an hour
#     => P(X = 15)

# Use dpois for Poisson probability
prob_exactly_15_calls <- dpois(15, 12)
prob_exactly_15_calls
